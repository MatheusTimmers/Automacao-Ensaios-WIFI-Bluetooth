IVI Foundation Inc. IVI Session Factory Readme File
        Version 1.1.1.3

============================================================================
Version History

1.0.1.0
	- First formal issue.

1.0.1.1
	- Added oleautomation to idl.

1.0.1.2
	- Removed redundant CoInitializeEx call.

1.1.1.3
	- Support IIviComponentIdenity
	- Dual Build 64Bit & Win32

============================================================================
Copyright � 2002-2008, IVI Foundation Inc.  All Rights Reserved.
